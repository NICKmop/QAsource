package com.webix.gpl.vo;

public class menulistVO {
	
}
