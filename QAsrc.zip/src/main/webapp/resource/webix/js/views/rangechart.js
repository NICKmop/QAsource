
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"rangechart", defaults:{
	template:"GPL version doesn't support rangechart <br> You need Webix PRO"
}}, template.view);