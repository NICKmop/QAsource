
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"flexdatalayout", defaults:{
	template:"GPL version doesn't support flexdatalayout <br> You need Webix PRO"
}}, template.view);