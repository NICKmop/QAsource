
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"checksuggest", defaults:{
	template:"GPL version doesn't support checksuggest <br> You need Webix PRO"
}}, template.view);