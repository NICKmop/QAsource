
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"multiselect", defaults:{
	template:"GPL version doesn't support multiselect <br> You need Webix PRO"
}}, template.view);