
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"gage", defaults:{
	template:"GPL version doesn't support gage <br> You need Webix PRO"
}}, template.view);