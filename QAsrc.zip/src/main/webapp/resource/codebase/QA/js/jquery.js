$( document ).ready( function() {
	console.log($(".jqueryTest").children());
} );