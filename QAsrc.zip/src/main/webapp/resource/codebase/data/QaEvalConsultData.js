var Qpi_small_film_set = [
	{test1:"",test2:"첫인사2",test3:"15.0",test4:"2",test5:"선택형",test6:"2",test7:"관리자1",test8:"2021-07-22",controldata:"cs컨설팅팀",rrr:"알기쉽게 논리적으로 설명하여 해결 방안 제시"},
	{test1:"",test2:"첫인사",test3:"15.0",test4:"2",test5:"선택형",test6:"2",test7:"관리자1",test8:"2021-07-22",controldata:"세일즈팀",rrr:"친절하고 밝은 음성으로 미소와 감정이입이 이루어져 친근감이 있는 겨웅"},
	{test1:"",test2:"마무리인사",test3:"15.0",test4:"2",test5:"선택형",test6:"2",test7:"관리자1",test8:"2021-07-22",controldata:"세일즈팀1",rrr:""},
	{test1:"",test2:"첫인사/끝인사",test3:"15.0",test4:"2",test5:"선택형",test6:"2",test7:"관리자1",test8:"2021-07-22",controldata:"세일즈팀2",rrr:""},
	{test1:"",test2:"[검증_인바운드]업무처리정화도_문제해결능력",test3:"15.0",test4:"2",test5:"선택형",test6:"2",test7:"관리자1",test8:"2021-07-22",controldata:"세일즈팀3",rrr:""},
	{test1:"",test2:"[검증_인바운드]응대태도_감성연출",test3:"15.0",test4:"2",test5:"선택형",test6:"2",test7:"관리자1",test8:"2021-07-22",controldata:"세일즈팀4",rrr:""},
	{test1:"가입기회발굴",test2:"혜택",test3:"15.0",test4:"2",test5:"선택형",test6:"2",test7:"관리자1",test8:"2021-07-22",controldata:"세일즈팀5"},
	{test1:"기본품질",test2:"일할",test3:"15.0",test4:"2",test5:"선택형",test6:"2",test7:"관리자1",test8:"2021-07-22",controldata:"세일즈팀6"},
	{test1:"Easily(이해하기 쉬운설명)",test2:"테스트",test3:"15.0",test4:"2",test5:"선택형",test6:"2",test7:"관리자1",test8:"2021-07-22",controldata:"세일즈팀7"},
];

var QaaData = [
	{ch1:"",test1:"111",test2:"11항목명",test3:"2",test4:"선택형"},
	{ch1:"",test1:"111",test2:"11항목명",test3:"2",test4:"선택형"},
	{ch1:"",test1:"111",test2:"11항목명",test3:"2",test4:"선택형"},
	{ch1:"",test1:"111",test2:"11항목명",test3:"2",test4:"선택형"},
	{ch1:"",test1:"111",test2:"11항목명",test3:"2",test4:"선택형"},
	{ch1:"",test1:"111",test2:"11항목명",test3:"2",test4:"선택형"}
];
var UserData = [
	{ch1:"",test1:"22222",test2:"22항목명",test3:"15.0",test4:"2"},
	{ch1:"",test1:"22222",test2:"22항목명",test3:"15.0",test4:"2"},
	{ch1:"",test1:"22222",test2:"22항목명",test3:"15.0",test4:"2"},
	{ch1:"",test1:"22222",test2:"22항목명",test3:"15.0",test4:"2"},
	{ch1:"",test1:"22222",test2:"22항목명",test3:"15.0",test4:"2"},
	{ch1:"",test1:"22222",test2:"22항목명",test3:"15.0",test4:"2"},
	{ch1:"",test1:"22222",test2:"22항목명",test3:"15.0",test4:"2"},
	{ch1:"",test1:"22222",test2:"22항목명",test3:"15.0",test4:"2"},
	{ch1:"",test1:"22222",test2:"22항목명",test3:"15.0",test4:"2"},
];