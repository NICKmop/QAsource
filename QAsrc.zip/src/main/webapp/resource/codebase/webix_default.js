webix.ready(function(){
	// fnc 모음
	webixUiList();
});
