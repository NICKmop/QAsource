package com.webix.gpl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebixSpringframeworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
